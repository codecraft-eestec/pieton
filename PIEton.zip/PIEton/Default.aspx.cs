﻿using System;
using System.Web;
using System.Web.UI;
//using MySQL.Data;
//using MySQL.Web;

namespace PIEton
{
	
	public partial class Default : System.Web.UI.Page
	{
		public void button1Clicked (object sender, EventArgs args)
		{
			
		}
	}
}

